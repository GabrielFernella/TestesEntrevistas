package Hackaton.ApiJava2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiJava2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
