package Hackaton.ApiJava2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiJava2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiJava2Application.class, args);
	}

}
